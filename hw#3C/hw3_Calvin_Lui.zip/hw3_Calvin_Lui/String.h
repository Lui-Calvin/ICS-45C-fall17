#define MAXLEN 128
#include <iostream>
using namespace std;
class String
{
	private:
		bool inBounds(int i)
		{
			return i >= 0 && i < MAXLEN;
		}
		static int strlen(const char *s)
		{
			int i = 0;
			while(s[i] != '\0')
			{
				++i;
			}
			return i;
		}
		static char* strcpy(char *dest, const char *src)
		{
			
			int i;
			for(i = 0;src[i] != '\0';++i)
			{
				dest[i] = src[i];
			}
			dest[i] = src[i];
			return dest;
		}

		static char * strcat(char *dest, const char* src)
		{
			if(strlen(dest) + strlen(src))
			{
				int i;
				int j;
				for(i = strlen(dest), j = 0;src[j] != '\0';++i,++j)
				{
					dest[i] = src[j];
				}
				dest[i] = '\0';
			} else {
				cout << "failed to concatenate, insufficient space" << endl;
			}
			return dest;
			
		}
		
		static int strcmp(const char* left, const char* right)
		{
			for(int i = 0; left[i] != '\0';++i)
			{
				if(left[i] != right[i])
				{
					return left[i] - right[i];
				}
			}
			return 0;
		}
		
		static int strncmp(const char *left, const char* right,int num)
		{
			for(int i = 0; left[i] != '\0' && i < num;++i)
			{
				if(left[i] !=  right[i])
				{
					return left[i] - right[i];
				}
			}
			return 0;
		}
		static char * strchr(char *str,int c)
		{
			return &str[c];
		}

		static const char* strstr(const char *haystack, const char* needle)
		{
			char* w = (char*)haystack;
			return strstr(w,needle);
		}

		static char* strstr(char* haystack, const char * needle)
		{
			int needle_len = strlen(needle),i = 0;
			while(strchr(haystack,i))
			{
				if (strncmp(strchr(haystack,i),needle,needle_len) == 0)
				{
					cout << i << endl;
					return &haystack[i];
				}
				++i;
			}
			return nullptr;
		}
	
		static void reverse_cpy(char *dest, const char * src)
		{
			int j = 0;
			for(int i = strlen(src)-1; i >= 0; --i)
			{
				dest[j] = src[i];
				++j;
			}
			dest[j] = '\0';
		}

		char buf[MAXLEN];

	public:
	///both constructors should construct this String from the parameter s
	explicit String(const char * s = "")
	{		
		strcpy(buf,s);
	}
	String( const String & s )
	{
		strcpy(buf,s.buf);
	}
    	String operator = ( const String & s )
	{
		strcpy(buf,s.buf);
	}
    	char & operator [] ( int index )
	{
		return buf[index];
	}
    	int size()
	{
		return strlen(buf);
	}
    	String reverse()
	{
		char ret[MAXLEN];
		reverse_cpy(ret,buf);
		return String(ret);
	}
    	int indexOf( const char c )
	{
		for(int i = 0; buf[i] != '\0';++i)
		{
			if(buf[i] == c)
			{
				return i;
			}
		}
		return -1;
	}
    	int indexOf( const String pattern )
	{
		char* loc = strstr(buf,pattern.buf);
		return strlen(buf)-strlen(loc);
	}
    	bool operator == ( const String s )
	{
		return strcmp(buf,s.buf) == 0;
	}
    	bool operator != ( const String s )
	{
		return strcmp(buf,s.buf) != 0;
	}
    	bool operator > ( const String s )
	{
		return strcmp(buf,s.buf) > 0;
	}
    	bool operator < ( const String s )
	{
		return strcmp(buf,s.buf) < 0;
	}
    	bool operator <= ( const String s )
	{
		return strcmp(buf,s.buf) <= 0;
	}
    	bool operator >= ( const String s )
	{
		return strcmp(buf,s.buf) >= 0;
	}
    /// concatenates this and s to return result
    	String operator + ( const String s )
	{
		char ret[MAXLEN];
		strcpy(ret,buf);
		strcat(ret,s.buf);
		return String(ret);
		
	}
    /// concatenates s onto end of this string
    	String operator += ( const String s )
	{
		strcat(buf,s.buf);
		return *this;
	}
	void print( ostream & out )
	{
		for(int i = 0; buf[i] != '\0'; ++i)
		{
			cout << buf[i];
		}
	}
	void read( istream & in )
	{
		char input[MAXLEN];
		cin.getline(input,MAXLEN);
		strcpy(buf,input);
	}
	~String()
	{
	}

};
ostream & operator << (ostream & out, String str)
{
	str.print(out);
	return out;
}
istream & operator >> (istream & in, String & str)
{
	str.read(in);
	return in;
}
